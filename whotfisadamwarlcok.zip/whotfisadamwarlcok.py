import discord
from discord.ext import commands

intents = discord.Intents.default()
intents.message_content = True

bot = commands.Bot(command_prefix='!', intents=intents)

ADAM_WARLOCK_INFO = """adam warlock is a marvel hero: in the comics, he's assosciated with immense cosmic power as a result of essentially being genetically engineered to be the perfect human being, and as  a result, he's considerered one of the most powerful heroes iin the universe. He's so powerful that he  actually  ends up being the vessel for the soul stone, so he shows up  a lot in thanos stories. this was probably what was going to happen in the MCU until disney and james gunn fought each other.
i hope that answers your question."""

@bot.event
async def on_ready():
    print(f'{bot.user} is ready to share Marvel knowledge!')

@bot.event
async def on_message(message):
    if message.author == bot.user:
        return

    content = message.content.lower()
    if ("who" in content or "Who" in message.content) and "adam warlock" in content:
        await message.channel.send(ADAM_WARLOCK_INFO)

    await bot.process_commands(message)

bot.run('MTMyMTk4ODg1MjM5ODY5MDM3NA.GjTHE_.E9wIRHEvR4m3Vi3Pl770SljYy2XFopRIKj2rtY')
